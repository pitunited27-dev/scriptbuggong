module.exports = {
  BOT_TOKEN:
  "7763699852:AAHRqfuC-nYUSD9Qza_sDdYM1gptA1kAW6I",
};

/*

▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓

🩸  СКРИПТ : Nortside Infinity
🩸  ВЕРСИЯ : 1.4
🩸  РАЗРАБОТЧИК : KyzzOfficial
🩸  РАЗРАБОТЧИК 2 : Tepzofficial

🌫️ Рождён в тумане холода...
🌑 Нашептан мраком ночи...
🕯️ И подчиняется лишь своему хозяину...

⚠️ Не трогай... если не готов принять проклятие.

📌 Telegram : https://t.me/KyzzOfficial

💀 Благодарности:
- Аллах С.В.Т.
- SevsBotz
- Khafa Jomok
- ChatGPT
- Верные пользователи

© KYZZOFFICIAL – Все права поглощены тьмой

▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓

*/
